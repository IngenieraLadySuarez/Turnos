﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TurnosWebApi.Context;
using TurnosWebApi.Models;

namespace TurnosWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ComerciosController : ControllerBase
    {
        private readonly ApplicationDBcontext _context;

        public ComerciosController(ApplicationDBcontext context)
        {
            _context = context;
        }

        // GET: api/Comercios
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Comercios>>> GetComercios()
        {
            return await _context.Comercios.ToListAsync();
        }

        // GET: api/Comercios/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Comercios>> GetComercios(int id)
        {
            var comercios = await _context.Comercios.FindAsync(id);

            if (comercios == null)
            {
                return NotFound();
            }

            return comercios;
        }

        // PUT: api/Comercios/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutComercios(int id, Comercios comercios)
        {
            if (id != comercios.IdComercio)
            {
                return BadRequest();
            }

            _context.Entry(comercios).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ComerciosExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Comercios
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Comercios>> PostComercios(Comercios comercios)
        {
            _context.Comercios.Add(comercios);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetComercios", new { id = comercios.IdComercio }, comercios);
        }

        // DELETE: api/Comercios/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteComercios(int id)
        {
            var comercios = await _context.Comercios.FindAsync(id);
            if (comercios == null)
            {
                return NotFound();
            }

            _context.Comercios.Remove(comercios);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool ComerciosExists(int id)
        {
            return _context.Comercios.Any(e => e.IdComercio == id);
        }
    }
}
