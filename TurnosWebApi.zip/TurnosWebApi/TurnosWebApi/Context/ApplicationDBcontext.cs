﻿using Microsoft.EntityFrameworkCore;
using TurnosWebApi.Models;

namespace TurnosWebApi.Context
{
    public class ApplicationDBcontext: DbContext
    {
        public DbSet <Turnos> Turnos { get; set; }
        public DbSet<Servicios> Servicios { get; set; }
        public DbSet<Comercios> Comercios { get; set; }
        
        public ApplicationDBcontext(DbContextOptions<ApplicationDBcontext> options)
        : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            
            modelBuilder.Entity<Servicios>()
                .HasOne(s => s.Comercio)
                .WithMany()
                .HasForeignKey(s => s.IdComercio);
            modelBuilder.Entity<Turnos>()
                .HasOne(t => t.Servicio)
                .WithMany()
                .HasForeignKey(t => t.IdServicio);
            base.OnModelCreating(modelBuilder);
        }
    }
}
