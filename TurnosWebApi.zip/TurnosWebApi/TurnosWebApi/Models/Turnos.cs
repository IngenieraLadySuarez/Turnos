﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TurnosWebApi.Models
{
    public class Turnos
    {
        [Key]
        public int IdTurnos { get; set; }
        [Required]
        public int IdServicio { get; set; }
        [Required]
        public DateTime FechaTurno { get; set; }
        [Required]
        public TimeSpan HoraInicio { get; set; }
        public TimeSpan HoraFin { get; set; }

        [ForeignKey("IdServicio")]
        public Servicios Servicio { get; set; }
    }
}
