﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TurnosWebApi.Models
{
    public class SPGenerarTurnos
    {
        public DateTime FechaInicio { get; set; }
        public DateTime FechaFin { get; set; }
        public int IdServicio { get; set; }
    }
}
