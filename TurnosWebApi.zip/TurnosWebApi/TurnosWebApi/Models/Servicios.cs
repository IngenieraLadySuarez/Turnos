﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TurnosWebApi.Models
{
    public class Servicios
    {
        [Key]
        public int IdServicio { get; set; }
        [Required]
        public int IdComercio { get; set; }
        [Required]
        [StringLength(255)]
        public string NombreServicio { get; set; }
        [Required]
        public TimeSpan HoraApertura { get; set; }
        [Required]
        public TimeSpan HoraCierre { get; set; }
        [Required]
        public int DuracionMinutos
        {
            get
            {
                // Calcula la diferencia en minutos entre HoraCierre y HoraApertura
                return (int)(HoraCierre - HoraApertura).TotalMinutes;
            }
        }


        [ForeignKey("IdComercio")]
        public Comercios Comercio { get; set; }
    }
}
